// AutoApprove RPA — Motor Universal de Automação, Comboboxes & Gravação Livre
// Sistema de Execução com Disparo Universal de Eventos, Suporte a Dropdowns & Auto-Wait
(function () {
  if (window.__AUTOAPPROVE_CONTENT_SCRIPT_INITIALIZED__) {
    return;
  }
  window.__AUTOAPPROVE_CONTENT_SCRIPT_INITIALIZED__ = true;

  let isExecuting = false;
  let executionHUD = null;
  let activeRecordingMode = null; // 'free' | 'list_wizard' | null
  let wizardPhase = null; // 'list_row' | 'detail_steps' | 'return_action' | 'next_page'
  let recordedSteps = [];
  let waitingForElementMode = false;
  let isPaused = false;
  let hudMinimized = false;
  let wizardListConfig = {
    listRowSelector: '',
    openDetailSelector: '',
    returnSelector: '',
    returnMode: 'click_button',
    nextPageSelector: '',
    paginationEnabled: false,
  };

  // ==========================================
  // UTILITÁRIOS BÁSICOS
  // ==========================================

  function sleep(ms) {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }

  // Normaliza o elemento alvo durante a gravação para focar no componente interativo
  // (ex: ao clicar no chevron SVG, span ou ícone dentro de um combobox ou botão)
  function normalizeTargetForRecording(el) {
    if (!el || el.nodeType !== 1) return el;
    if (el.closest('#autoapprove-hud') || el.closest('#autoapprove-exec-hud')) return el;

    const interactiveTrigger = el.closest(
      'button, a, input, select, textarea, [role="combobox"], [role="button"], [role="option"], [role="menuitem"], [role="menuitemcheckbox"], [role="menuitemradio"], [role="tab"], [role="switch"], [aria-haspopup], [data-state], [tabindex]:not([tabindex="-1"]), summary, label, .select__control, .ant-select-selector, .MuiSelect-select, .headlessui-listbox-button, .dropdown-toggle'
    );
    if (interactiveTrigger) {
      return interactiveTrigger;
    }

    return el;
  }

  // Resolve o elemento correto na execução: se o elemento for um ícone inerte, sobe para o gatilho;
  // se for um wrapper genérico contendo um combobox/botão único, desce até ele.
  function resolveInteractiveTarget(el) {
    if (!el || el.nodeType !== 1) return el;

    if (el.tagName === 'path' || el.tagName === 'svg' || (el.tagName === 'SPAN' && !el.getAttribute('role'))) {
      const parentTrigger = el.closest(
        'button, [role="combobox"], [role="button"], [role="option"], [role="menuitem"], [role="tab"], [role="switch"], select, input, a, summary, [aria-haspopup], [data-state], .select__control, .ant-select-selector, .MuiSelect-select, label'
      );
      if (parentTrigger) return parentTrigger;
    }

    if (!el.matches('button, select, input, a, [role="combobox"], [role="option"], [role="menuitem"], [role="button"]')) {
      const innerTrigger = el.querySelector('[role="combobox"], [role="button"], button, select, input');
      if (innerTrigger && el.children.length <= 4) {
        return innerTrigger;
      }
    }

    return el;
  }

  // Verifica se o elemento está carregado, visível e pronto para receber interação
  function isElementActionable(el) {
    if (!el || !document.body.contains(el)) return false;

    if (el.tagName === 'SELECT') {
      return !el.disabled && el.getAttribute('aria-disabled') !== 'true';
    }

    const style = window.getComputedStyle(el);
    if (style.display === 'none' || style.visibility === 'hidden') {
      return false;
    }
    if (parseFloat(style.opacity || '1') < 0.05 && !el.matches('input[type="file"], select')) {
      return false;
    }

    const rect = el.getBoundingClientRect();
    if (rect.width === 0 && rect.height === 0 && el.children.length === 0) {
      return false;
    }

    if (el.disabled || el.getAttribute('aria-disabled') === 'true') {
      return false;
    }

    if (el.classList.contains('disabled') || el.classList.contains('is-loading')) {
      return false;
    }

    return true;
  }

  // Aguarda que bloqueadores de tela, spinners, loaders e barras de progresso sumam
  async function waitForBlockersToVanish(timeoutMs = 12000) {
    const start = Date.now();
    const blockerSelectors = [
      '[aria-busy="true"]',
      '.spinner:not(.hidden)',
      '.loading-spinner:not(.hidden)',
      '.loader:not(.hidden)',
      '[data-loading="true"]',
      '.modal-backdrop.loading',
      '.nprogress-busy',
      '.ant-spin-spinning',
      '.MuiCircularProgress-root',
    ];

    while (Date.now() - start < timeoutMs) {
      let isBlocked = false;
      for (const sel of blockerSelectors) {
        try {
          const els = document.querySelectorAll(sel);
          for (const el of Array.from(els)) {
            const style = window.getComputedStyle(el);
            if (style.display !== 'none' && style.visibility !== 'hidden' && parseFloat(style.opacity || '1') > 0.1) {
              isBlocked = true;
              break;
            }
          }
        } catch {}
        if (isBlocked) break;
      }

      if (!isBlocked) {
        return true;
      }
      await sleep(150);
    }
    return false;
  }

  // Aguarda que mutações no DOM cessem por um período determinado (quietMs)
  function waitForDomMutationQuiet(quietMs = 350, maxWaitMs = 6000) {
    return new Promise((resolve) => {
      let quietTimer = null;
      let totalTimer = null;

      const observer = new MutationObserver(() => {
        if (quietTimer) clearTimeout(quietTimer);
        quietTimer = setTimeout(finish, quietMs);
      });

      function finish() {
        if (quietTimer) clearTimeout(quietTimer);
        if (totalTimer) clearTimeout(totalTimer);
        observer.disconnect();
        resolve(true);
      }

      totalTimer = setTimeout(finish, maxWaitMs);
      observer.observe(document.body || document.documentElement, {
        childList: true,
        subtree: true,
        attributes: true,
      });

      quietTimer = setTimeout(finish, quietMs);
    });
  }

  // Motor central de Auto-Wait pós-ação: aguarda requisições, spinners e acomodação visual
  async function waitForActionSettled(baseExtraMs = 450) {
    await waitForBlockersToVanish(10000);
    await waitForDomMutationQuiet(300, 5000);

    if (document.readyState !== 'complete') {
      await new Promise((r) => {
        const h = () => {
          document.removeEventListener('DOMContentLoaded', h);
          window.removeEventListener('load', h);
          r();
        };
        document.addEventListener('DOMContentLoaded', h, { once: true });
        window.addEventListener('load', h, { once: true });
        setTimeout(h, 4000);
      });
    }

    if (baseExtraMs > 0) {
      await sleep(baseExtraMs);
    }
  }

  // Localiza o elemento interativo com busca por CSS, XPath, ARIA, portais de dropdown e texto
  async function findActionableElement(step, timeoutMs = 15000) {
    const start = Date.now();
    while (Date.now() - start < timeoutMs) {
      if (!isExecuting) throw new Error('Execução cancelada pelo usuário.');

      await waitForBlockersToVanish(1000);

      // 1. Tenta Seletor CSS Principal
      if (step.cssSelector) {
        try {
          const candidate = document.querySelector(step.cssSelector);
          if (candidate && isElementActionable(candidate)) {
            return resolveInteractiveTarget(candidate);
          }
        } catch {}
      }

      // 2. Tenta XPath se gravado
      if (step.xpath) {
        try {
          const result = document.evaluate(step.xpath, document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null);
          if (result.singleNodeValue && isElementActionable(result.singleNodeValue)) {
            return resolveInteractiveTarget(result.singleNodeValue);
          }
        } catch {}
      }

      // 3. Tenta Busca Especializada para Opções de Dropdown / Menus Abertos
      const cleanOptionText = (step.optionText || step.value || (step.label || '').replace(/^Escolher opção |^Selecionar em |^Clicar em /i, '')).replace(/["']/g, '').trim();
      if (cleanOptionText.length >= 1 && (step.isOption || step.role === 'option' || step.action === 'select')) {
        const openMenus = Array.from(
          document.querySelectorAll(
            '[role="listbox"], [role="menu"], .select__menu, .ant-select-dropdown, .MuiPopover-root, .dropdown-menu, [data-radix-popper-content-wrapper], ul.dropdown, .custom-select-menu'
          )
        );
        for (const menu of openMenus) {
          const optCandidates = Array.from(
            menu.querySelectorAll('[role="option"], [role="menuitem"], li, .select__option, .ant-select-item-option, .MuiMenuItem-root, .dropdown-item, button, a')
          );
          const foundOpt = optCandidates.find((opt) => {
            if (!isElementActionable(opt)) return false;
            const t = (opt.innerText || opt.textContent || opt.getAttribute('data-value') || '').trim();
            return t.toLowerCase() === cleanOptionText.toLowerCase() || t.toLowerCase().includes(cleanOptionText.toLowerCase());
          });
          if (foundOpt) return resolveInteractiveTarget(foundOpt);
        }
      }

      // 4. Tenta Seletor Semântico por Texto ou Rótulo em Elementos Interativos Gerais
      if (step.label) {
        const cleanText = step.label
          .replace(/^Clicar em |^Preencher campo |^Marcar opção |^Selecionar em |^Abrir caixa de seleção |^Escolher opção |^Aguardar elemento /i, '')
          .replace(/["']/g, '')
          .trim();
        if (cleanText.length >= 2) {
          const candidates = Array.from(
            document.querySelectorAll(
              'button, a, input, select, textarea, [role="combobox"], [role="button"], [role="option"], [role="menuitem"], [role="menuitemcheckbox"], [role="tab"], [role="switch"], [role="listbox"], li, label, summary, [aria-haspopup], [data-state], .select__control, .select__option, .ant-select-selector, .ant-select-item, .MuiSelect-select, .MuiMenuItem-root, .dropdown-item, .dropdown-toggle, tr, td, th'
            )
          );
          const match = candidates.find((c) => {
            if (!isElementActionable(c)) return false;
            const text = (
              c.innerText ||
              c.textContent ||
              c.getAttribute('aria-label') ||
              c.getAttribute('placeholder') ||
              c.getAttribute('title') ||
              c.id ||
              ''
            ).trim();
            return text.toLowerCase().includes(cleanText.toLowerCase());
          });
          if (match) return resolveInteractiveTarget(match);
        }
      }

      await sleep(200);
    }

    throw new Error(
      `Tempo limite ({Math.round(timeoutMs / 1000)}s) aguardando carregamento do elemento: {step.label} [{step.cssSelector}]`
    );
  }

  // ==========================================
  // DISPARADOR UNIVERSAL DE EVENTOS & DROPDOWNS
  // ==========================================

  // Executa uma interação de clique realista com coordenadas precisas, cadeia completa
  // de PointerEvents, ativação de <select> nativo e acionamento WAI-ARIA de fallback
  async function performClick(rawEl, step = {}) {
    const el = resolveInteractiveTarget(rawEl);

    // 1. Centralização suave do elemento na viewport
    try {
      el.scrollIntoView({ block: 'center', inline: 'center', behavior: 'smooth' });
    } catch {
      el.scrollIntoView();
    }
    highlightElement(el, '#2563eb');
    await sleep(150);

    // 2. Coordenadas precisas de clique no centro do elemento
    const rect = el.getBoundingClientRect();
    const xPct = step.coords && step.coords.xPct ? Number(step.coords.xPct) : 0.5;
    const yPct = step.coords && step.coords.yPct ? Number(step.coords.yPct) : 0.5;
    const clientX = Math.round(rect.left + Math.max(2, Math.min(rect.width - 2, rect.width * xPct)));
    const clientY = Math.round(rect.top + Math.max(2, Math.min(rect.height - 2, rect.height * yPct)));
    const screenX = (window.screenX || 0) + clientX;
    const screenY = (window.screenY || 0) + clientY;

    const baseEventProps = {
      bubbles: true,
      cancelable: true,
      composed: true,
      view: window,
      detail: 1,
      clientX,
      clientY,
      screenX,
      screenY,
      ctrlKey: false,
      altKey: false,
      shiftKey: false,
      metaKey: false,
    };

    const makePointerEvent = (type, buttons = 0, button = 0) => {
      try {
        return new PointerEvent(type, {
          ...baseEventProps,
          button,
          buttons,
          pointerId: 1,
          pointerType: 'mouse',
          isPrimary: true,
          width: 1,
          height: 1,
          pressure: buttons > 0 ? 0.5 : 0,
        });
      } catch {
        return new MouseEvent(type, { ...baseEventProps, button, buttons });
      }
    };

    // 3. Sequência Realista de Eventos de Ponteiro (compatível com Radix, React-Select, AntD, MUI, Headless UI)
    el.dispatchEvent(makePointerEvent('pointerover', 0, 0));
    el.dispatchEvent(new MouseEvent('mouseover', { ...baseEventProps, button: 0, buttons: 0 }));
    el.dispatchEvent(makePointerEvent('pointerenter', 0, 0));
    el.dispatchEvent(new MouseEvent('mouseenter', { ...baseEventProps, button: 0, buttons: 0 }));
    el.dispatchEvent(makePointerEvent('pointermove', 0, 0));

    // Pressionamento do botão
    el.dispatchEvent(makePointerEvent('pointerdown', 1, 0));
    el.dispatchEvent(new MouseEvent('mousedown', { ...baseEventProps, button: 0, buttons: 1 }));

    // Foco do elemento
    try {
      el.focus({ preventScroll: true });
    } catch {}
    el.dispatchEvent(new FocusEvent('focusin', { bubbles: true }));
    el.dispatchEvent(new FocusEvent('focus', { bubbles: false }));

    // Simulação do tempo natural do clique humano (40ms)
    await sleep(40);

    // Liberação do botão
    el.dispatchEvent(makePointerEvent('pointerup', 0, 0));
    el.dispatchEvent(new MouseEvent('mouseup', { ...baseEventProps, button: 0, buttons: 0 }));

    // Disparo de clique composto e invocação nativa
    el.dispatchEvent(new MouseEvent('click', { ...baseEventProps, button: 0, buttons: 0 }));
    try {
      el.click();
    } catch {}

    // 4. Suporte a <select> nativo via showPicker (Chromium 99+)
    if (el.tagName === 'SELECT') {
      try {
        if (typeof el.showPicker === 'function') {
          el.showPicker();
        }
      } catch {}
    }

    // 5. Verificação & Ativação WAI-ARIA de Fallback para Dropdowns e Comboboxes
    const isCombobox =
      el.getAttribute('role') === 'combobox' ||
      el.getAttribute('aria-haspopup') === 'listbox' ||
      el.getAttribute('aria-haspopup') === 'menu' ||
      el.getAttribute('aria-haspopup') === 'true' ||
      el.classList.contains('select__control') ||
      el.classList.contains('ant-select-selector') ||
      el.classList.contains('MuiSelect-select') ||
      el.classList.contains('headlessui-listbox-button') ||
      el.classList.contains('dropdown-toggle');

    if (isCombobox) {
      await sleep(100);
      const isExpanded =
        el.getAttribute('aria-expanded') === 'true' ||
        el.getAttribute('data-state') === 'open' ||
        Boolean(
          document.querySelector(
            '[role="listbox"]:not([hidden]), [role="menu"]:not([hidden]), .select__menu, .ant-select-dropdown:not(.ant-select-dropdown-hidden), .MuiPopover-root:not([aria-hidden="true"]), .dropdown-menu.show'
          )
        );

      if (!isExpanded) {
        // Dispara ArrowDown (atalho universal W3C para abrir comboboxes acessíveis)
        el.dispatchEvent(
          new KeyboardEvent('keydown', {
            key: 'ArrowDown',
            code: 'ArrowDown',
            keyCode: 40,
            which: 40,
            bubbles: true,
            cancelable: true,
          })
        );
        el.dispatchEvent(
          new KeyboardEvent('keyup', {
            key: 'ArrowDown',
            code: 'ArrowDown',
            keyCode: 40,
            which: 40,
            bubbles: true,
            cancelable: true,
          })
        );

        // Dispara Space / Enter se ainda não tiver expandido
        await sleep(60);
        const stillClosed =
          el.getAttribute('aria-expanded') !== 'true' &&
          !document.querySelector(
            '[role="listbox"]:not([hidden]), [role="menu"]:not([hidden]), .select__menu, .ant-select-dropdown:not(.ant-select-dropdown-hidden)'
          );
        if (stillClosed) {
          el.dispatchEvent(
            new KeyboardEvent('keydown', {
              key: ' ',
              code: 'Space',
              keyCode: 32,
              which: 32,
              bubbles: true,
              cancelable: true,
            })
          );
          el.dispatchEvent(
            new KeyboardEvent('keyup', {
              key: ' ',
              code: 'Space',
              keyCode: 32,
              which: 32,
              bubbles: true,
              cancelable: true,
            })
          );
        }
      }
    }
  }

  // ==========================================
  // SELETORES RESILIENTES PARA GRAVAÇÃO
  // ==========================================

  function getResilientSelector(el) {
    if (!el || el.nodeType !== 1) return 'body';

    // 1. Atributos Semânticos de Automação & Teste
    if (el.dataset && el.dataset.action) return {el.tagName.toLowerCase()}[data-action="{el.dataset.action}"];
    if (el.dataset && el.dataset.testid) return {el.tagName.toLowerCase()}[data-testid="{el.dataset.testid}"];
    if (el.dataset && el.dataset.qa) return {el.tagName.toLowerCase()}[data-qa="{el.dataset.qa}"];
    if (el.dataset && el.dataset.cy) return {el.tagName.toLowerCase()}[data-cy="{el.dataset.cy}"];

    // 2. ID Estável (Ignora IDs dinâmicos gerados por frameworks)
    if (el.id && !/\\d{4,}/.test(el.id) && !/^(:r|react|ng|ember|vue|_)/i.test(el.id)) {
      return #{CSS.escape(el.id)};
    }

    // 3. Comboboxes e Caixas de Seleção Acessíveis
    if (el.getAttribute('role') === 'combobox') {
      const ariaLabel = el.getAttribute('aria-label');
      if (ariaLabel) return [role="combobox"][aria-label="{ariaLabel.replace(/"/g, '\\\\"')}"];
      const name = el.getAttribute('name');
      if (name) return [role="combobox"][name="{name.replace(/"/g, '\\\\"')}"];
      return '[role="combobox"]';
    }

    // 4. Opções de Listbox / Menus Abertos
    if (el.getAttribute('role') === 'option') {
      const dataVal = el.getAttribute('data-value') || el.getAttribute('value');
      if (dataVal) return [role="option"][data-value="{dataVal.replace(/"/g, '\\\\"')}"];
      const text = (el.innerText || '').trim();
      if (text && text.length <= 30) {
        return [role="option"]:has-text("{text.replace(/"/g, '\\\\"')}");
      }
      return '[role="option"]';
    }

    // 5. Atributos Acessíveis & Nomes de Formulário
    const ariaLabel = el.getAttribute('aria-label');
    if (ariaLabel) {
      return {el.tagName.toLowerCase()}[aria-label="{ariaLabel.replace(/"/g, '\\\\"')}"];
    }
    const name = el.getAttribute('name');
    if (name) {
      return {el.tagName.toLowerCase()}[name="{name.replace(/"/g, '\\\\"')}"];
    }
    const placeholder = el.getAttribute('placeholder');
    if (placeholder) {
      return {el.tagName.toLowerCase()}[placeholder="{placeholder.replace(/"/g, '\\\\"')}"];
    }
    const title = el.getAttribute('title');
    if (title) {
      return {el.tagName.toLowerCase()}[title="{title.replace(/"/g, '\\\\"')}"];
    }

    // 6. Botão, Link ou Gatilho com Classe Estável
    if (
      el.tagName === 'BUTTON' ||
      el.tagName === 'A' ||
      el.getAttribute('role') === 'button' ||
      el.classList.contains('select__control') ||
      el.classList.contains('ant-select-selector') ||
      el.classList.contains('MuiSelect-select')
    ) {
      if (el.className && typeof el.className === 'string') {
        const firstClass = el.className
          .split(/\\s+/)
          .filter((c) => c && !c.includes(':') && !c.startsWith('hover:') && !c.startsWith('focus:') && !/\\d{5,}/.test(c))[0];
        if (firstClass) {
          const count = document.querySelectorAll('.' + CSS.escape(firstClass)).length;
          if (count === 1) return .{CSS.escape(firstClass)};
          if (count > 1 && count <= 5) {
            const index = Array.from(document.querySelectorAll('.' + CSS.escape(firstClass))).indexOf(el);
            if (index >= 0) return .{CSS.escape(firstClass)}:nth-of-type({index + 1});
          }
        }
      }
    }

    // 7. Hierarquia com nth-of-type seguro
    if (el.parentElement) {
      const parentSelector = getResilientSelector(el.parentElement);
      const tag = el.tagName.toLowerCase();
      const siblings = Array.from(el.parentElement.children).filter((c) => c.tagName === el.tagName);
      if (siblings.length === 1) {
        return {parentSelector} > {tag};
      }
      const index = siblings.indexOf(el);
      return {parentSelector} > {tag}:nth-of-type({index + 1});
    }

    return el.tagName.toLowerCase();
  }

  function getXPath(el) {
    if (!el || el.nodeType !== 1) return '';
    if (el.id && !/\\d{4,}/.test(el.id)) return //*[@id="{el.id}"];

    const text = (el.innerText || '').trim();
    if (el.getAttribute('role') === 'option' && text && text.length < 30) {
      return //*[@role="option" and contains(., '{text.replace(/'/g, "\\\\'")}')];
    }
    if ((el.tagName === 'BUTTON' || el.tagName === 'A' || el.getAttribute('role') === 'button') && text && text.length < 30) {
      return //{el.tagName.toLowerCase()}[contains(text(), '{text.replace(/'/g, "\\\\'")}')];
    }

    if (el === document.body) return '/html/body';
    let ix = 0;
    const siblings = el.parentNode ? el.parentNode.childNodes : [];
    for (let i = 0; i < siblings.length; i++) {
      const sibling = siblings[i];
      if (sibling === el) {
        return {getXPath(el.parentNode)}/{el.tagName.toLowerCase()}[{ix + 1}];
      }
      if (sibling.nodeType === 1 && sibling.tagName === el.tagName) {
        ix++;
      }
    }
    return '';
  }

  function getAriaSelector(el) {
    if (!el) return '';
    const role =
      el.getAttribute('role') ||
      (el.tagName === 'BUTTON'
        ? 'button'
        : el.tagName === 'A'
        ? 'link'
        : el.type === 'checkbox'
        ? 'checkbox'
        : el.tagName === 'SELECT' || el.getAttribute('role') === 'combobox'
        ? 'combobox'
        : el.tagName === 'INPUT'
        ? 'textbox'
        : el.tagName.toLowerCase());

    const name =
      el.getAttribute('aria-label') ||
      (el.innerText || '').trim().slice(0, 30) ||
      el.getAttribute('name') ||
      el.id ||
      '';

    if (name) {
      return role={role}[name="{name.replace(/"/g, '\\\\"') }"];
    }
    return role={role};
  }

  function getCleanLabel(el, actionType) {
    const text = (
      el.innerText ||
      el.getAttribute('aria-label') ||
      el.getAttribute('title') ||
      el.getAttribute('placeholder') ||
      el.getAttribute('name') ||
      el.id ||
      ''
    ).trim();
    const shortText = text ? "{text.slice(0, 28)}" : el.tagName.toLowerCase();

    if (actionType === 'fill') return Preencher campo {shortText};
    if (actionType === 'check') return Marcar opção {shortText};
    if (actionType === 'select') return Selecionar em {shortText};
    if (actionType === 'choose_option') return Escolher opção {shortText};
    if (actionType === 'open_dropdown') return Abrir caixa de seleção {shortText};
    if (actionType === 'navigate') return Navegar para página {shortText};
    if (actionType === 'wait_visible') return Aguardar elemento {shortText} ficar visível;
    return Clicar em {shortText};
  }

  function highlightElement(el, color = '#10b981') {
    if (!el || !el.style) return;
    const prevOutline = el.style.outline;
    const prevTransition = el.style.transition;
    el.style.transition = 'outline 0.15s ease-in-out';
    el.style.outline = 3px solid {color};
    setTimeout(() => {
      try {
        el.style.outline = prevOutline;
        el.style.transition = prevTransition;
      } catch {}
    }, 700);
  }

  function sendLog(level, message, outcome = null) {
    chrome.runtime.sendMessage({
      type: 'UPDATE_STATS',
      logEntry: {
        timestamp: new Date().toLocaleTimeString(),
        level,
        message,
        outcome,
      },
    }).catch(() => {});
  }

  // ==========================================
  // HUD DE EXECUÇÃO EM TEMPO REAL
  // ==========================================

  function renderExecutionHUD(info) {
    let hud = document.getElementById('autoapprove-exec-hud');
    if (!hud) {
      hud = document.createElement('div');
      hud.id = 'autoapprove-exec-hud';
      hud.style.cssText = 
        position: fixed;
        bottom: 24px;
        right: 24px;
        z-index: 2147483647;
        background: #0f172a;
        color: #f8fafc;
        border: 2px solid #3b82f6;
        border-radius: 12px;
        box-shadow: 0 10px 25px -5px rgba(0,0,0,0.5);
        font-family: system-ui, -apple-system, sans-serif;
        font-size: 13px;
        padding: 14px 18px;
        width: 320px;
        display: flex;
        flex-direction: column;
        gap: 8px;
      ;
      document.body.appendChild(hud);
    }

    const { taskName, stepIndex, totalSteps, label, waitingSettle } = info;

    hud.innerHTML = 
      <div style="display: flex; align-items: center; justify-content: space-between; border-bottom: 1px solid #334155; padding-bottom: 6px;">
        <div style="display: flex; align-items: center; gap: 6px;">
          <span style="display: inline-block; width: 8px; height: 8px; border-radius: 50%; background: #22c55e; animation: pulse 1.5s infinite;"></span>
          <strong style="font-size: 12px; color: #94a3b8; text-transform: uppercase; letter-spacing: 0.5px;">AutoApprove Executando</strong>
        </div>
        <button id="exec-hud-btn-abort" style="background: transparent; border: none; color: #ef4444; font-weight: bold; cursor: pointer; font-size: 12px;">Parar [ESC]</button>
      </div>
      <div style="font-weight: 600; color: #e2e8f0; font-size: 13px;">{taskName || 'Automação Ativa'}</div>
      <div style="font-size: 12px; color: #38bdf8; display: flex; align-items: center; gap: 6px;">
        <span>Passo {stepIndex}/{totalSteps}:</span>
        <span style="color: #f1f5f9; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; max-width: 190px;">{label || ''}</span>
      </div>
      {
        waitingSettle
          ? '<div style="font-size: 11px; color: #fbbf24; background: rgba(251, 191, 36, 0.1); padding: 4px 8px; border-radius: 4px; display: flex; items-center; gap: 4px;"><span>⏳</span><span>Aguardando carregamento da ação...</span></div>'
          : '<div style="font-size: 11px; color: #94a3b8; padding: 2px 0;">⚡ Executando disparo universal...</div>'
      }
      <div style="height: 4px; background: #334155; border-radius: 2px; overflow: hidden; margin-top: 2px;">
        <div style="height: 100%; width: {Math.min(100, Math.round((stepIndex / totalSteps) * 100))}%; background: #3b82f6; transition: width 0.3s;"></div>
      </div>
    ;

    document.getElementById('exec-hud-btn-abort')?.addEventListener('click', () => {
      isExecuting = false;
      hud.remove();
      sendLog('warn', 'Execução abortada pelo operador via HUD.');
    });
  }

  // ==========================================
  // MOTOR DE EXECUÇÃO DE MACROS LIVRES
  // ==========================================

  async function executeFreeMacroTask(task, config, startFromStepIdx = 0, currentCycle = 1) {
    if (!task || isExecuting) return;
    isExecuting = true;

    const baseDelayMs = Number(config.baseDelayMs) || 450;
    const randomJitterMs = Number(config.randomJitterMs) || 200;
    const repeatCount = task.repeatMode === 'repeat_n' ? Number(task.repeatCount) || 1 : 1;
    const steps = task.steps || [];

    sendLog('info', Iniciando execução de "{task.name}" com Disparador Universal de Comboboxes (Ciclo {currentCycle}/{repeatCount})...);

    try {
      for (let cycle = currentCycle; cycle <= repeatCount; cycle++) {
        if (!isExecuting) break;

        const sStart = cycle === currentCycle ? startFromStepIdx : 0;
        for (let sIdx = sStart; sIdx < steps.length; sIdx++) {
          if (!isExecuting) break;
          const step = steps[sIdx];

          chrome.storage.local.set({
            rpaExecutionSession: {
              active: true,
              taskId: task.id,
              cycle,
              repeatCount,
              nextStepIdx: sIdx + 1,
              config,
            },
          }).catch(() => {});

          renderExecutionHUD({
            taskName: task.name,
            stepIndex: sIdx + 1,
            totalSteps: steps.length,
            label: step.label,
            waitingSettle: false,
          });

          await sleep(Math.max(150, step.waitBeforeMs || 300) + Math.floor(Math.random() * randomJitterMs));

          try {
            if (step.action === 'sleep') {
              const ms = Number(step.value) || 2000;
              sendLog('info', Aguardando {ms / 1000}s conforme programado...);
              await sleep(ms);
              continue;
            }

            if (step.action === 'navigate' && step.value) {
              if (window.location.href !== step.value) {
                sendLog('info', Navegando para: {step.value}...);
                window.location.href = step.value;
                return;
              }
              continue;
            }

            // Localiza elemento interativo garantindo que está carregado e renderizado
            const el = await findActionableElement(step, step.timeoutMs || 15000);

            if (step.action === 'fill') {
              el.scrollIntoView({ block: 'center', behavior: 'smooth' });
              highlightElement(el, '#10b981');
              el.focus();
              const valSetter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value')?.set;
              if (valSetter && (el.tagName === 'INPUT' || el.tagName === 'TEXTAREA')) {
                valSetter.call(el, step.value || '');
              } else {
                el.value = step.value || '';
              }
              el.dispatchEvent(new Event('input', { bubbles: true }));
              el.dispatchEvent(new Event('change', { bubbles: true }));
              el.dispatchEvent(new Event('blur', { bubbles: true }));
            } else if (step.action === 'check') {
              if (!el.checked && el.getAttribute('aria-checked') !== 'true') {
                await performClick(el, step);
              }
            } else if (step.action === 'select') {
              if (el.tagName === 'SELECT') {
                el.scrollIntoView({ block: 'center', behavior: 'smooth' });
                highlightElement(el, '#10b981');
                el.value = step.value || '';
                for (const opt of Array.from(el.options || [])) {
                  if (opt.value === step.value || opt.text.trim() === (step.value || '').trim()) {
                    opt.selected = true;
                    el.value = opt.value;
                    break;
                  }
                }
                el.dispatchEvent(new Event('input', { bubbles: true }));
                el.dispatchEvent(new Event('change', { bubbles: true }));
              } else {
                // Dropdown/Combobox Customizado: clica para abrir
                await performClick(el, step);
              }
            } else if (step.action === 'wait_visible') {
              highlightElement(el, '#facc15');
            } else {
              // CLIQUE UNIVERSAL: aciona comboboxes, dropdowns e botões com cadeia de eventos completa
              await performClick(el, step);
            }

            sendLog('info', Passo {sIdx + 1}/{steps.length} concluído: {step.label});

            renderExecutionHUD({
              taskName: task.name,
              stepIndex: sIdx + 1,
              totalSteps: steps.length,
              label: step.label,
              waitingSettle: true,
            });

            await waitForActionSettled(baseDelayMs);
          } catch (stepErr) {
            sendLog('warn', Aviso no passo {sIdx + 1} ({step.label}): {String(stepErr.message)});
            await sleep(800);
          }
        }
      }

      await chrome.storage.local.set({ rpaExecutionSession: { active: false } });
      sendLog('success', Tarefa "{task.name}" finalizada com sucesso!, 'completed');
    } catch (err) {
      sendLog('error', Falha na execução de "{task.name}": {err.message});
    } finally {
      isExecuting = false;
      document.getElementById('autoapprove-exec-hud')?.remove();
      chrome.runtime.sendMessage({ type: 'STOP_BATCH_EXECUTION' }).catch(() => {});
    }
  }

  // ==========================================
  // MOTOR DE WORKFLOW EM LOTE (TABELA + MODAL)
  // ==========================================

  async function executeBatchTableWorkflow(task, config) {
    if (isExecuting) return;
    isExecuting = true;

    const baseDelayMs = Number(config.baseDelayMs) || 500;
    const randomJitterMs = Number(config.randomJitterMs) || 250;
    const maxRetries = Number(config.maxRetries) || 3;

    const listConfig = task.listConfig || {};
    const rowSelector = listConfig.listRowSelector || 'tr[data-id], .tabela-solicitacoes tbody tr';
    const openDetailSelector = listConfig.openDetailSelector || null;
    const returnSelector = listConfig.returnSelector || null;
    const returnMode = listConfig.returnMode || 'click_button';
    const nextPageSelector = listConfig.nextPageSelector || null;
    const paginationEnabled = Boolean(listConfig.paginationEnabled);
    const detailSteps = (task.steps || []).filter((s) => s.isLoopTarget);

    let approvedTotal = 0;
    let currentPage = 1;

    sendLog('info', 'Iniciando Processamento em Lote com Disparador Universal e Auto-Wait...');

    try {
      while (isExecuting) {
        await waitForActionSettled(500);

        const rows = Array.from(document.querySelectorAll(rowSelector)).filter((r) => {
          const text = (r.innerText || '').toLowerCase();
          return !text.includes('aprovado') && !text.includes('rejeitado') && !text.includes('concluído');
        });

        if (rows.length === 0) {
          if (paginationEnabled && nextPageSelector) {
            const nextBtn = document.querySelector(nextPageSelector);
            if (nextBtn && isElementActionable(nextBtn)) {
              sendLog('info', Avançando para página {currentPage + 1}...);
              await performClick(nextBtn);
              currentPage += 1;
              await waitForActionSettled(baseDelayMs);
              continue;
            }
          }
          sendLog('success', Processamento finalizado! Total de {approvedTotal} aprovações.);
          break;
        }

        for (let i = 0; i < rows.length; i++) {
          if (!isExecuting) break;
          const row = rows[i];
          const itemId = row.getAttribute('data-id') || row.querySelector('strong, .protocolo-id')?.innerText || Item #{i + 1};

          for (let attempt = 1; attempt <= maxRetries; attempt++) {
            try {
              row.scrollIntoView({ block: 'center', behavior: 'smooth' });
              highlightElement(row);
              await sleep(baseDelayMs + Math.floor(Math.random() * randomJitterMs));

              const openBtn = (openDetailSelector ? row.querySelector(openDetailSelector) : null) || row.querySelector('button, a') || row;
              await performClick(openBtn);

              await waitForActionSettled(500);

              for (const step of detailSteps) {
                if (!isExecuting) return;

                renderExecutionHUD({
                  taskName: task.name,
                  stepIndex: step.order || 1,
                  totalSteps: detailSteps.length,
                  label: step.label,
                  waitingSettle: false,
                });

                await sleep(step.waitBeforeMs + Math.floor(Math.random() * randomJitterMs));
                const el = await findActionableElement(step, step.timeoutMs || 10000);

                if (step.action === 'check') {
                  if (!el.checked && el.getAttribute('aria-checked') !== 'true') await performClick(el, step);
                } else if (step.action === 'select' && step.value) {
                  if (el.tagName === 'SELECT') {
                    el.scrollIntoView({ block: 'center', behavior: 'instant' });
                    highlightElement(el);
                    el.value = step.value;
                    for (const opt of Array.from(el.options || [])) {
                      if (opt.value === step.value || opt.text.trim() === step.value.trim()) {
                        opt.selected = true;
                        el.value = opt.value;
                        break;
                      }
                    }
                    el.dispatchEvent(new Event('change', { bubbles: true }));
                  } else {
                    await performClick(el, step);
                  }
                } else if (step.action === 'fill' && step.value) {
                  el.scrollIntoView({ block: 'center', behavior: 'instant' });
                  highlightElement(el);
                  const valSetter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value')?.set;
                  if (valSetter && (el.tagName === 'INPUT' || el.tagName === 'TEXTAREA')) {
                    valSetter.call(el, step.value);
                  } else {
                    el.value = step.value;
                  }
                  el.dispatchEvent(new Event('input', { bubbles: true }));
                  el.dispatchEvent(new Event('change', { bubbles: true }));
                } else {
                  await performClick(el, step);
                }

                await waitForActionSettled(baseDelayMs);
              }

              await sleep(350);
              if (returnMode === 'history_back') {
                window.history.back();
              } else if (returnSelector && document.querySelector(returnSelector)) {
                const backBtn = document.querySelector(returnSelector);
                if (backBtn && isElementActionable(backBtn)) await performClick(backBtn);
              } else {
                const fallbackBack = document.querySelector(
                  'button#btn-cancelar-aprovacao, button.btn-voltar, .modal-backdrop button, [data-action="close-modal"]'
                );
                if (fallbackBack && isElementActionable(fallbackBack)) await performClick(fallbackBack);
              }

              await waitForActionSettled(500);

              approvedTotal += 1;
              sendLog('success', {itemId} aprovado com sucesso! ({approvedTotal}), 'approved');
              chrome.runtime.sendMessage({
                type: 'UPDATE_STATS',
                patch: { approved: approvedTotal, currentPage },
              }).catch(() => {});
              break;
            } catch (err) {
              sendLog('warn', Tentativa {attempt} falhou para {itemId}: {err.message});
              if (attempt >= maxRetries) {
                sendLog('error', Falha definitiva ao aprovar {itemId}.);
              }
              await sleep(800);
            }
          }
        }
      }
    } finally {
      isExecuting = false;
      document.getElementById('autoapprove-exec-hud')?.remove();
    }
  }

  // ==========================================
  // PERSISTÊNCIA MULTI-PÁGINAS DURANTE A GRAVAÇÃO
  // ==========================================

  function persistSessionState() {
    if (!activeRecordingMode) return;
    chrome.storage.local.get(['rpaRecordingSession'], (res) => {
      const current = res.rpaRecordingSession || {};
      const updated = {
        ...current,
        active: true,
        mode: activeRecordingMode,
        status: isPaused ? 'paused' : 'recording',
        recordedSteps,
        wizardPhase,
        wizardListConfig,
        lastUrl: window.location.href,
        lastPageTitle: document.title,
        hudMinimized,
        updatedAt: new Date().toISOString(),
      };
      chrome.storage.local.set({ rpaRecordingSession: updated }).catch(() => {});
    });
  }

  function addRecordedStep(step) {
    recordedSteps.push(step);
    persistSessionState();
    chrome.runtime.sendMessage({
      type: 'SYNC_RECORDING_STEP',
      stepCount: recordedSteps.length,
      lastStep: step,
    }).catch(() => {});
    renderHUD();
  }

  // ==========================================
  // HUD DE GRAVAÇÃO FLUTUANTE (SOBREVIVE A NAVEGAÇÃO)
  // ==========================================

  function renderHUD(options = {}) {
    let hud = document.getElementById('autoapprove-hud');
    if (!hud) {
      hud = document.createElement('div');
      hud.id = 'autoapprove-hud';
      document.body.appendChild(hud);
    }

    if (hudMinimized) {
      hud.innerHTML = 
        <div id="hud-drag-handle" style="display: flex; align-items: center; gap: 8px; cursor: move; padding: 8px 12px; background: #0f172a; color: #f8fafc; border: 2px solid #ef4444; border-radius: 9999px; box-shadow: 0 10px 25px -5px rgba(0,0,0,0.5); font-family: system-ui, sans-serif; font-size: 12px;">
          <span style="display: inline-block; width: 10px; height: 10px; border-radius: 50%; background: #ef4444; animation: pulse 1s infinite;"></span>
          <strong>REC ({recordedSteps.length})</strong>
          <button id="hud-btn-expand" style="background: #334155; border: none; color: #fff; padding: 2px 6px; border-radius: 4px; cursor: pointer; font-size: 11px;">Expandir</button>
          <button id="hud-btn-quick-save" style="background: #10b981; border: none; color: #fff; padding: 2px 8px; border-radius: 4px; cursor: pointer; font-size: 11px; font-weight: bold;">Salvar</button>
        </div>
      ;
      document.getElementById('hud-btn-expand')?.addEventListener('click', () => {
        hudMinimized = false;
        persistSessionState();
        renderHUD();
      });
      document.getElementById('hud-btn-quick-save')?.addEventListener('click', finishRecording);
      setupDraggable(hud);
      return;
    }

    const isList = activeRecordingMode === 'list_wizard';
    let phaseInstruction = '';

    if (isList) {
      if (wizardPhase === 'list_row') {
        phaseInstruction = '👉 <strong>Passo 1:</strong> Clique no botão "Abrir/Aprovar" de qualquer linha da tabela.';
      } else if (wizardPhase === 'detail_steps') {
        phaseInstruction = '👉 <strong>Passo 2:</strong> Dentro do modal ou página de detalhes, interaja com os campos (selecione dropdowns, marque checkboxes, clique em Aprovar).';
      } else if (wizardPhase === 'return_action') {
        phaseInstruction = '👉 <strong>Passo 3:</strong> Clique no botão para Voltar/Fechar o modal e retornar à lista.';
      } else if (wizardPhase === 'next_page') {
        phaseInstruction = '👉 <strong>Passo 4:</strong> Clique no botão de Próxima Página (ou finalize se não houver paginação).';
      }
    } else {
      phaseInstruction = '🔴 <strong>Gravação Ativa:</strong> Interaja normalmente na página. Comboboxes, menus, botões e navegações são capturados com fidelidade universal.';
    }

    const isNavigationJustHappened = options.isResumedAfterNavigation;

    hud.innerHTML = 
      <div style="
        position: fixed;
        bottom: 24px;
        right: 24px;
        z-index: 2147483647;
        background: #0f172a;
        color: #f8fafc;
        border: 2px solid #ef4444;
        border-radius: 14px;
        box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.6), 0 8px 10px -6px rgba(0, 0, 0, 0.6);
        font-family: system-ui, -apple-system, sans-serif;
        font-size: 13px;
        padding: 16px;
        width: 360px;
        display: flex;
        flex-direction: column;
        gap: 10px;
      ">
        <div id="hud-drag-handle" style="display: flex; align-items: center; justify-content: space-between; border-bottom: 1px solid #334155; padding-bottom: 8px; cursor: move;">
          <div style="display: flex; align-items: center; gap: 8px;">
            <span style="display: inline-block; width: 10px; height: 10px; border-radius: 50%; background: #ef4444; animation: pulse 1s infinite;"></span>
            <strong style="font-size: 12px; letter-spacing: 0.5px; text-transform: uppercase; color: #f87171;">
              {isList ? 'Assistente de Lista & Modais' : 'Gravação Livre na Tela'}
            </strong>
          </div>
          <div style="display: flex; align-items: center; gap: 6px;">
            <button id="hud-btn-minimize" title="Minimizar HUD" style="background: transparent; border: none; color: #94a3b8; cursor: pointer; font-size: 14px; padding: 2px 4px;">_</button>
            <span style="background: #1e293b; color: #38bdf8; font-size: 11px; padding: 2px 6px; border-radius: 4px; font-weight: bold;">
              {recordedSteps.length} passo{recordedSteps.length === 1 ? '' : 's'}
            </span>
          </div>
        </div>

        {
          isNavigationJustHappened
            ? 
          <div id="hud-nav-alert" style="background: #064e3b; border: 1px solid #10b981; color: #a7f3d0; padding: 6px 10px; border-radius: 6px; font-size: 11px; display: flex; align-items: center; justify-content: space-between;">
            <span>🛡️ <strong>Página Carregada:</strong> Gravação mantida com sucesso!</span>
            <button id="hud-btn-dismiss-nav" style="background: transparent; border: none; color: #a7f3d0; font-weight: bold; cursor: pointer;">✕</button>
          </div>
        
            : ''
        }

        <div style="background: #1e293b; padding: 8px 10px; border-radius: 6px; font-size: 12px; color: #e2e8f0; line-height: 1.4;">
          {phaseInstruction}
        </div>

        <div style="max-height: 140px; overflow-y: auto; display: flex; flex-direction: column; gap: 4px; background: #020617; padding: 6px; border-radius: 6px;">
          {
            recordedSteps.length === 0
              ? '<div style="color: #64748b; font-size: 11px; text-align: center; padding: 12px 0;">Nenhum passo gravado ainda.<br>Clique nos elementos da página.</div>'
              : recordedSteps
                  .slice(-5)
                  .map(
                    (s, i) => 
              <div style="font-size: 11px; display: flex; align-items: center; justify-content: space-between; color: #cbd5e1; background: #0f172a; padding: 4px 6px; border-radius: 4px;">
                <div style="display: flex; align-items: center; gap: 6px; overflow: hidden;">
                  <span style="color: #38bdf8; font-weight: bold;">#{s.order}</span>
                  <span style="overflow: hidden; text-overflow: ellipsis; white-space: nowrap; max-width: 200px;" title="{s.label}">{s.label}</span>
                </div>
                <span style="color: #64748b; font-size: 9px; text-transform: uppercase;">{s.action}</span>
              </div>
            
                  )
                  .join('')
          }
        </div>

        <div style="display: flex; flex-wrap: wrap; gap: 6px; border-top: 1px solid #334155; padding-top: 8px;">
          <button id="hud-btn-toggle-pause" style="flex: 1; min-width: 70px; background: {isPaused ? '#f59e0b' : '#334155'}; border: none; color: #fff; padding: 6px 8px; border-radius: 6px; font-size: 11px; cursor: pointer;">
            {isPaused ? '▶ Retomar' : '⏸ Pausar'}
          </button>
          <button id="hud-btn-add-delay" style="flex: 1; min-width: 80px; background: #334155; border: none; color: #fff; padding: 6px 8px; border-radius: 6px; font-size: 11px; cursor: pointer;">
            ⏳ + Pausa
          </button>
          <button id="hud-btn-add-nav" style="flex: 1; min-width: 90px; background: #334155; border: none; color: #fff; padding: 6px 8px; border-radius: 6px; font-size: 11px; cursor: pointer;">
            🔗 + Navegar
          </button>
          <button id="hud-btn-wait-el" style="flex: 1; min-width: 90px; background: {waitingForElementMode ? '#f59e0b' : '#334155'}; border: none; color: #fff; padding: 6px 8px; border-radius: 6px; font-size: 11px; cursor: pointer;">
            👁 + Esperar
          </button>
          <button id="hud-btn-undo" style="flex: 1; min-width: 70px; background: #334155; border: none; color: #fff; padding: 6px 8px; border-radius: 6px; font-size: 11px; cursor: pointer;" {recordedSteps.length === 0 ? 'disabled' : ''}>
            ↩ Desfazer
          </button>
        </div>

        {
          isList && wizardPhase === 'return_action'
            ? 
          <button id="hud-btn-use-history-back" style="background: #3b82f6; border: none; color: #fff; padding: 7px; border-radius: 6px; font-size: 11px; font-weight: bold; cursor: pointer;">
            ⬅ Usar Retorno pelo Histórico (Voltar Página)
          </button>
        
            : ''
        }

        <div style="display: flex; gap: 8px; border-top: 1px solid #334155; padding-top: 8px;">
          <button id="hud-btn-finish" style="flex: 2; background: #10b981; border: none; color: #fff; padding: 8px; border-radius: 6px; font-size: 12px; font-weight: bold; cursor: pointer;">
            💾 Salvar Gravação
          </button>
          <button id="hud-btn-close" style="flex: 1; background: #ef4444; border: none; color: #fff; padding: 8px; border-radius: 6px; font-size: 12px; cursor: pointer;">
            Cancelar
          </button>
        </div>
      </div>
    ;

    document.getElementById('hud-btn-minimize')?.addEventListener('click', () => {
      hudMinimized = true;
      persistSessionState();
      renderHUD();
    });

    document.getElementById('hud-btn-dismiss-nav')?.addEventListener('click', () => {
      document.getElementById('hud-nav-alert')?.remove();
    });

    document.getElementById('hud-btn-toggle-pause')?.addEventListener('click', () => {
      isPaused = !isPaused;
      persistSessionState();
      renderHUD();
      sendLog('info', isPaused ? 'Gravação pausada pelo usuário.' : 'Gravação retomada.');
    });

    document.getElementById('hud-btn-add-delay')?.addEventListener('click', () => {
      const msStr = prompt('Tempo de espera programada em segundos (ex: 2 ou 5):', '2');
      const s = Number(msStr) || 2;
      const step = {
        id: 'step-' + Date.now(),
        order: recordedSteps.length + 1,
        label: Aguardar {s}s,
        action: 'sleep',
        value: s * 1000,
        waitBeforeMs: 0,
        timeoutMs: s * 1000 + 1000,
        isLoopTarget: activeRecordingMode === 'list_wizard' && wizardPhase === 'detail_steps',
        url: window.location.href,
      };
      addRecordedStep(step);
    });

    document.getElementById('hud-btn-add-nav')?.addEventListener('click', () => {
      const url = prompt('URL para navegação programada:', window.location.href);
      if (url?.trim()) {
        const step = {
          id: 'step-' + Date.now(),
          order: recordedSteps.length + 1,
          label: Navegar para {url.trim()},
          action: 'navigate',
          value: url.trim(),
          waitBeforeMs: 500,
          timeoutMs: 15000,
          isLoopTarget: false,
          url: window.location.href,
        };
        addRecordedStep(step);
      }
    });

    document.getElementById('hud-btn-wait-el')?.addEventListener('click', () => {
      waitingForElementMode = true;
      alert('Clique no elemento que a automação deve aguardar ficar visível antes de continuar.');
      renderHUD();
    });

    document.getElementById('hud-btn-undo')?.addEventListener('click', () => {
      if (recordedSteps.length > 0) {
        const removed = recordedSteps.pop();
        persistSessionState();
        sendLog('info', Passo desfeito: {removed.label});
        renderHUD();
      }
    });

    document.getElementById('hud-btn-use-history-back')?.addEventListener('click', () => {
      wizardListConfig.returnMode = 'history_back';
      wizardPhase = 'next_page';
      persistSessionState();
      sendLog('info', 'Fase 3: Configurado retorno via histórico (Voltar Página).');
      renderHUD();
    });

    document.getElementById('hud-btn-finish')?.addEventListener('click', finishRecording);
    document.getElementById('hud-btn-close')?.addEventListener('click', cancelRecording);

    setupDraggable(hud);
  }

  function setupDraggable(hud) {
    const handle = hud.querySelector('#hud-drag-handle');
    if (!handle) return;
    let isDragging = false;
    let startX, startY, initialRight, initialBottom;

    handle.addEventListener('mousedown', (e) => {
      if (e.target.tagName === 'BUTTON') return;
      isDragging = true;
      startX = e.clientX;
      startY = e.clientY;
      const rect = hud.getBoundingClientRect();
      initialRight = window.innerWidth - rect.right;
      initialBottom = window.innerHeight - rect.bottom;
      document.body.style.userSelect = 'none';
    });

    window.addEventListener('mousemove', (e) => {
      if (!isDragging) return;
      const dx = startX - e.clientX;
      const dy = startY - e.clientY;
      hud.style.right = {Math.max(10, initialRight + dx)}px;
      hud.style.bottom = {Math.max(10, initialBottom + dy)}px;
    });

    window.addEventListener('mouseup', () => {
      if (isDragging) {
        isDragging = false;
        document.body.style.userSelect = '';
      }
    });
  }

  function closeHUD() {
    document.getElementById('autoapprove-hud')?.remove();
  }

  async function finishRecording() {
    const { rpaRecordingSession = {} } = await chrome.storage.local.get('rpaRecordingSession');
    const targetTaskId = rpaRecordingSession.taskId;

    chrome.runtime.sendMessage({
      type: 'SAVE_RECORDED_STEPS',
      taskId: targetTaskId,
      steps: recordedSteps,
      listConfig: wizardListConfig,
    }).catch(() => {});

    closeHUD();
    sendLog('success', Gravação concluída com {recordedSteps.length} passos salvos na tarefa!);
    activeRecordingMode = null;
    wizardPhase = null;
    recordedSteps = [];
  }

  async function cancelRecording() {
    if (confirm('Deseja realmente cancelar a gravação? Os passos não salvos serão descartados.')) {
      chrome.runtime.sendMessage({ type: 'CANCEL_RECORDING_SESSION' }).catch(() => {});
      activeRecordingMode = null;
      wizardPhase = null;
      recordedSteps = [];
      closeHUD();
      sendLog('warn', 'Gravação cancelada pelo usuário.');
    }
  }

  // ==========================================
  // CAPTURA HUMANA: CLIQUES & COMBOS
  // ==========================================

  document.addEventListener(
    'click',
    (ev) => {
      if (!activeRecordingMode || isPaused) return;

      const rawTarget = ev.target;
      if (rawTarget.closest('#autoapprove-hud') || rawTarget.closest('#autoapprove-exec-hud')) return;

      // Normaliza o elemento interativo (sobe de <path>, <svg> ou <span> para o botão/combobox)
      const target = normalizeTargetForRecording(rawTarget);
      if (target.closest('#autoapprove-hud') || target.closest('#autoapprove-exec-hud')) return;

      const selector = getResilientSelector(target);
      const ariaSelector = getAriaSelector(target);
      const xpath = getXPath(target);

      // Calcula coordenadas percentuais do clique dentro do elemento
      const rect = target.getBoundingClientRect();
      const coords = {
        xPct: rect.width > 0 ? ((ev.clientX - rect.left) / rect.width).toFixed(2) : '0.50',
        yPct: rect.height > 0 ? ((ev.clientY - rect.top) / rect.height).toFixed(2) : '0.50',
      };

      if (waitingForElementMode) {
        ev.preventDefault();
        ev.stopPropagation();
        const step = {
          id: 'step-' + Date.now(),
          order: recordedSteps.length + 1,
          label: getCleanLabel(target, 'wait_visible'),
          action: 'wait_visible',
          cssSelector: selector,
          ariaSelector,
          xpath,
          waitBeforeMs: 300,
          timeoutMs: 12000,
          isLoopTarget: false,
          url: window.location.href,
        };
        waitingForElementMode = false;
        highlightElement(target, '#facc15');
        addRecordedStep(step);
        return;
      }

      // Detecção de tipo semântico: Combobox, Opção, Checkbox, Select nativo ou Clique padrão
      const isCombobox =
        target.getAttribute('role') === 'combobox' ||
        target.getAttribute('aria-haspopup') === 'listbox' ||
        target.getAttribute('aria-haspopup') === 'menu' ||
        target.getAttribute('aria-haspopup') === 'true' ||
        target.classList.contains('select__control') ||
        target.classList.contains('ant-select-selector') ||
        target.classList.contains('MuiSelect-select') ||
        target.classList.contains('dropdown-toggle');

      const isOption =
        target.getAttribute('role') === 'option' ||
        target.getAttribute('role') === 'menuitem' ||
        target.classList.contains('select__option') ||
        target.classList.contains('ant-select-item-option') ||
        target.classList.contains('MuiMenuItem-root') ||
        target.classList.contains('dropdown-item');

      let action = 'click';
      if (target.type === 'checkbox' || target.getAttribute('role') === 'checkbox' || target.getAttribute('role') === 'switch') {
        action = 'check';
      } else if (target.tagName === 'SELECT') {
        action = 'select';
      }

      const label = getCleanLabel(
        target,
        isCombobox ? 'open_dropdown' : isOption ? 'choose_option' : action
      );

      const optionText = isOption ? (target.innerText || target.textContent || '').trim() : undefined;

      if (activeRecordingMode === 'free') {
        const step = {
          id: 'step-' + Date.now(),
          order: recordedSteps.length + 1,
          label,
          action,
          cssSelector: selector,
          ariaSelector,
          xpath,
          coords,
          isCombobox,
          isOption,
          optionText,
          role: target.getAttribute('role') || target.tagName.toLowerCase(),
          tagName: target.tagName,
          waitBeforeMs: 350,
          timeoutMs: 12000,
          isLoopTarget: false,
          url: window.location.href,
        };
        highlightElement(target);
        addRecordedStep(step);
        return;
      }

      if (activeRecordingMode === 'list_wizard') {
        if (wizardPhase === 'list_row') {
          wizardListConfig.openDetailSelector = selector;
          const row = target.closest('tr, li, .card, [data-id]');
          if (row) wizardListConfig.listRowSelector = getResilientSelector(row);
          wizardPhase = 'detail_steps';
          highlightElement(target);
          persistSessionState();
          sendLog('info', Fase 1 Gravada: Abertura de item ({selector}));
          renderHUD();
        } else if (wizardPhase === 'detail_steps') {
          const step = {
            id: 'step-' + Date.now(),
            order: recordedSteps.length + 1,
            label,
            action,
            cssSelector: selector,
            ariaSelector,
            xpath,
            coords,
            isCombobox,
            isOption,
            optionText,
            role: target.getAttribute('role') || target.tagName.toLowerCase(),
            tagName: target.tagName,
            waitBeforeMs: 350,
            timeoutMs: 10000,
            isLoopTarget: true,
            url: window.location.href,
          };
          highlightElement(target);
          addRecordedStep(step);
        } else if (wizardPhase === 'return_action') {
          wizardListConfig.returnSelector = selector;
          wizardListConfig.returnMode = 'click_button';
          wizardPhase = 'next_page';
          highlightElement(target);
          persistSessionState();
          sendLog('info', Fase 3 Gravada: Botão de Retorno ({selector}));
          renderHUD();
        } else if (wizardPhase === 'next_page') {
          wizardListConfig.nextPageSelector = selector;
          wizardListConfig.paginationEnabled = true;
          highlightElement(target);
          sendLog('info', Fase 4 Gravada: Botão de Paginação ({selector}));
          finishRecording();
        }
      }
    },
    true
  );

  // Intercepta Mudanças em Inputs e <select> nativo durante a gravação
  document.addEventListener(
    'change',
    (ev) => {
      if (!activeRecordingMode || isPaused) return;
      const target = ev.target;
      if (target.closest('#autoapprove-hud') || target.closest('#autoapprove-exec-hud')) return;

      const selector = getResilientSelector(target);
      const ariaSelector = getAriaSelector(target);
      const xpath = getXPath(target);

      if (
        (target.tagName === 'INPUT' && target.type !== 'checkbox' && target.type !== 'radio') ||
        target.tagName === 'TEXTAREA'
      ) {
        const step = {
          id: 'step-' + Date.now(),
          order: recordedSteps.length + 1,
          label: getCleanLabel(target, 'fill'),
          action: 'fill',
          cssSelector: selector,
          ariaSelector,
          xpath,
          value: target.value,
          waitBeforeMs: 300,
          timeoutMs: 8000,
          isLoopTarget: activeRecordingMode === 'list_wizard' && wizardPhase === 'detail_steps',
          url: window.location.href,
        };
        highlightElement(target);
        addRecordedStep(step);
      } else if (target.tagName === 'SELECT') {
        const step = {
          id: 'step-' + Date.now(),
          order: recordedSteps.length + 1,
          label: getCleanLabel(target, 'select'),
          action: 'select',
          cssSelector: selector,
          ariaSelector,
          xpath,
          value: target.value,
          waitBeforeMs: 250,
          timeoutMs: 6000,
          isLoopTarget: activeRecordingMode === 'list_wizard' && wizardPhase === 'detail_steps',
          url: window.location.href,
        };
        highlightElement(target);
        addRecordedStep(step);
      }
    },
    true
  );

  // Antes do descarregamento da página, garante salvamento de estado no storage
  window.addEventListener('beforeunload', () => {
    if (activeRecordingMode) {
      persistSessionState();
    }
  });

  // ==========================================
  // RESTAURAÇÃO DE SESSÃO APÓS NAVEGAÇÃO
  // ==========================================

  async function checkAndResumeState() {
    try {
      const { rpaRecordingSession = {}, rpaExecutionSession = {}, rpaTasks = [] } =
        await chrome.storage.local.get(['rpaRecordingSession', 'rpaExecutionSession', 'rpaTasks']);

      // 1. Restaura Gravação Ativa se houver navegação entre páginas
      if (rpaRecordingSession && rpaRecordingSession.active) {
        activeRecordingMode = rpaRecordingSession.mode || 'free';
        wizardPhase = rpaRecordingSession.wizardPhase || null;
        wizardListConfig = rpaRecordingSession.wizardListConfig || {};
        recordedSteps = rpaRecordingSession.recordedSteps || [];
        hudMinimized = Boolean(rpaRecordingSession.hudMinimized);
        isPaused = rpaRecordingSession.status === 'paused';

        const lastUrl = rpaRecordingSession.lastUrl;
        const isNewPage = lastUrl && lastUrl !== window.location.href;

        if (isNewPage) {
          const navStep = {
            id: 'step-nav-' + Date.now(),
            order: recordedSteps.length + 1,
            label: Carregamento da Página ({document.title || window.location.pathname}),
            action: 'wait_visible',
            cssSelector: 'body',
            waitBeforeMs: 600,
            timeoutMs: 15000,
            isLoopTarget: activeRecordingMode === 'list_wizard' && wizardPhase === 'detail_steps',
            url: window.location.href,
          };
          recordedSteps.push(navStep);
          persistSessionState();
        }

        renderHUD({ isResumedAfterNavigation: isNewPage });
        sendLog('info', Sessão de Gravação restaurada na página: {window.location.pathname});
      }

      // 2. Restaura Execução em Andamento se um clique navegou de página
      if (rpaExecutionSession && rpaExecutionSession.active) {
        const { taskId, cycle, repeatCount, nextStepIdx, config } = rpaExecutionSession;
        const task = rpaTasks.find((t) => t.id === taskId);
        if (task && nextStepIdx < (task.steps || []).length) {
          sendLog('info', Retomando execução de "{task.name}" no passo {nextStepIdx + 1} após carregamento de página...);
          await waitForActionSettled(800);
          executeFreeMacroTask(task, config, nextStepIdx, cycle);
        } else {
          chrome.storage.local.set({ rpaExecutionSession: { active: false } }).catch(() => {});
        }
      }
    } catch (e) {
      console.warn('[AutoApprove] Erro ao restaurar estado:', e);
    }
  }

  // ==========================================
  // DISPATCHER DE MENSAGENS DO SERVICE WORKER
  // ==========================================

  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (msg.type === 'RPA_EXECUTE_TASK') {
      if (msg.task?.pattern === 'list_batch') {
        executeBatchTableWorkflow(msg.task, msg.config || {});
      } else {
        executeFreeMacroTask(msg.task, msg.config || {});
      }
      sendResponse({ ok: true, executing: true });
    } else if (msg.type === 'RPA_ABORT') {
      isExecuting = false;
      document.getElementById('autoapprove-exec-hud')?.remove();
      sendLog('warn', 'Execução interrompida via painel.');
      sendResponse({ ok: true });
    } else if (msg.type === 'RPA_START_RECORDING') {
      activeRecordingMode = msg.mode || 'free';
      wizardPhase = msg.mode === 'list_wizard' ? 'list_row' : null;
      recordedSteps = [];
      hudMinimized = false;
      isPaused = false;
      renderHUD();
      sendResponse({ ok: true });
    } else if (msg.type === 'RPA_RESUME_RECORDING') {
      const s = msg.session || {};
      activeRecordingMode = s.mode || 'free';
      wizardPhase = s.wizardPhase || null;
      wizardListConfig = s.wizardListConfig || {};
      recordedSteps = s.recordedSteps || [];
      hudMinimized = Boolean(s.hudMinimized);
      isPaused = s.status === 'paused';
      renderHUD({ isResumedAfterNavigation: true });
      sendResponse({ ok: true });
    } else if (msg.type === 'RPA_PING') {
      sendResponse({ ok: true, recording: Boolean(activeRecordingMode), executing: isExecuting });
    }
    return true;
  });

  // Inicializa verificação de gravação ou execução
  checkAndResumeState();
})();
